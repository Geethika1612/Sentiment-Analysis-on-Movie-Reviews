# AI-Project
Sentiment Analysis on Movie Reviews
